--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

DROP INDEX public.suoyin_zidian_yonghuzu;
DROP INDEX public.suoyin_zidian_yonghu;
DROP INDEX public.suoyin_zidian_mokuai;
DROP INDEX public.suoyin_zidian_caidan;
ALTER TABLE ONLY public.zidian_yonghuzu DROP CONSTRAINT zhujian_zidian_yonghuzu;
ALTER TABLE ONLY public.zidian_yonghu DROP CONSTRAINT zhujian_zidian_yonghu;
ALTER TABLE ONLY public.zidian_mokuai DROP CONSTRAINT zhujian_zidian_mokuai;
ALTER TABLE ONLY public.zidian_jiazai DROP CONSTRAINT zhujian_zidian_jiazai;
ALTER TABLE ONLY public.zidian_caidan DROP CONSTRAINT zhujian_zidian_caidan;
ALTER TABLE ONLY public.xinxi_yonghuzuquanxian DROP CONSTRAINT zhujian_xinxi_yonghuzuquanxian;
ALTER TABLE ONLY public.xinxi_yonghuquanxian DROP CONSTRAINT zhujian_xinxi_yonghuquanxian;
ALTER TABLE ONLY public.xinxi_shouquan DROP CONSTRAINT zhujian_xinxi_shouquan;
ALTER TABLE ONLY public.rizhi_denglu DROP CONSTRAINT zhujian_rizhi_denglu;
ALTER TABLE ONLY public.guanxi_fenzu DROP CONSTRAINT zhujian_guanxi_fenzu;
ALTER TABLE ONLY public.zidian_yonghuzu DROP CONSTRAINT yueshu_zidian_yonghuzu;
ALTER TABLE ONLY public.zidian_yonghu DROP CONSTRAINT yueshu_zidian_yonghu;
ALTER TABLE ONLY public.zidian_mokuai DROP CONSTRAINT yueshu_zidian_mokuai;
ALTER TABLE ONLY public.zidian_jiazai DROP CONSTRAINT yueshu_zidian_jiazai;
ALTER TABLE ONLY public.zidian_caidan DROP CONSTRAINT yueshu_zidian_caidan_shunxu;
ALTER TABLE ONLY public.zidian_caidan DROP CONSTRAINT yueshu_zidian_caidan_biaoti;
ALTER TABLE public.rizhi_denglu ALTER COLUMN xuhao DROP DEFAULT;
DROP TABLE public.zidian_yonghuzu;
DROP TABLE public.zidian_yonghu;
DROP TABLE public.zidian_mokuai;
DROP TABLE public.zidian_jiazai;
DROP TABLE public.zidian_caidan;
DROP TABLE public.xinxi_yonghuzuquanxian;
DROP TABLE public.xinxi_yonghuquanxian;
DROP TABLE public.xinxi_shouquan;
DROP SEQUENCE public.rizhi_denglu_xuhao_seq;
DROP TABLE public.rizhi_denglu;
DROP TABLE public.guanxi_fenzu;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: guanxi_fenzu; Type: TABLE; Schema: public; Owner: sa; Tablespace: 
--

CREATE TABLE guanxi_fenzu (
    yonghuzuid integer NOT NULL,
    yonghuid integer NOT NULL
);


ALTER TABLE public.guanxi_fenzu OWNER TO sa;

--
-- Name: TABLE guanxi_fenzu; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON TABLE guanxi_fenzu IS '用户分组关系表';


--
-- Name: COLUMN guanxi_fenzu.yonghuzuid; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN guanxi_fenzu.yonghuzuid IS '用户组ID';


--
-- Name: COLUMN guanxi_fenzu.yonghuid; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN guanxi_fenzu.yonghuid IS '用户ID';


--
-- Name: rizhi_denglu; Type: TABLE; Schema: public; Owner: sa; Tablespace: 
--

CREATE TABLE rizhi_denglu (
    xuhao integer NOT NULL,
    caozuoneirong integer NOT NULL,
    caozuoshijian timestamp without time zone NOT NULL,
    caozuorenyuanid integer NOT NULL
);


ALTER TABLE public.rizhi_denglu OWNER TO sa;

--
-- Name: TABLE rizhi_denglu; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON TABLE rizhi_denglu IS '登录日志表';


--
-- Name: COLUMN rizhi_denglu.xuhao; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN rizhi_denglu.xuhao IS '序号';


--
-- Name: COLUMN rizhi_denglu.caozuoneirong; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN rizhi_denglu.caozuoneirong IS '操作内容';


--
-- Name: COLUMN rizhi_denglu.caozuoshijian; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN rizhi_denglu.caozuoshijian IS '操作时间';


--
-- Name: COLUMN rizhi_denglu.caozuorenyuanid; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN rizhi_denglu.caozuorenyuanid IS '操作人员id';


--
-- Name: rizhi_denglu_xuhao_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE rizhi_denglu_xuhao_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rizhi_denglu_xuhao_seq OWNER TO sa;

--
-- Name: rizhi_denglu_xuhao_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE rizhi_denglu_xuhao_seq OWNED BY rizhi_denglu.xuhao;


--
-- Name: xinxi_shouquan; Type: TABLE; Schema: public; Owner: sa; Tablespace: 
--

CREATE TABLE xinxi_shouquan (
    xuliehao text NOT NULL,
    cpuid text
);


ALTER TABLE public.xinxi_shouquan OWNER TO sa;

--
-- Name: TABLE xinxi_shouquan; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON TABLE xinxi_shouquan IS '程序授权信息表';


--
-- Name: COLUMN xinxi_shouquan.xuliehao; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN xinxi_shouquan.xuliehao IS '序列号';


--
-- Name: COLUMN xinxi_shouquan.cpuid; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN xinxi_shouquan.cpuid IS 'cpuid';


--
-- Name: xinxi_yonghuquanxian; Type: TABLE; Schema: public; Owner: sa; Tablespace: 
--

CREATE TABLE xinxi_yonghuquanxian (
    mokuaiid integer NOT NULL,
    yonghuid integer NOT NULL
);


ALTER TABLE public.xinxi_yonghuquanxian OWNER TO sa;

--
-- Name: TABLE xinxi_yonghuquanxian; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON TABLE xinxi_yonghuquanxian IS '用户权限信息表';


--
-- Name: COLUMN xinxi_yonghuquanxian.mokuaiid; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN xinxi_yonghuquanxian.mokuaiid IS '模块ID';


--
-- Name: COLUMN xinxi_yonghuquanxian.yonghuid; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN xinxi_yonghuquanxian.yonghuid IS '用户ID';


--
-- Name: xinxi_yonghuzuquanxian; Type: TABLE; Schema: public; Owner: sa; Tablespace: 
--

CREATE TABLE xinxi_yonghuzuquanxian (
    yonghuzuid integer NOT NULL,
    mokuaiid integer NOT NULL
);


ALTER TABLE public.xinxi_yonghuzuquanxian OWNER TO sa;

--
-- Name: TABLE xinxi_yonghuzuquanxian; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON TABLE xinxi_yonghuzuquanxian IS '用户组权限信息表';


--
-- Name: COLUMN xinxi_yonghuzuquanxian.yonghuzuid; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN xinxi_yonghuzuquanxian.yonghuzuid IS '用户组ID';


--
-- Name: COLUMN xinxi_yonghuzuquanxian.mokuaiid; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN xinxi_yonghuzuquanxian.mokuaiid IS '模块ID';


--
-- Name: zidian_caidan; Type: TABLE; Schema: public; Owner: sa; Tablespace: 
--

CREATE TABLE zidian_caidan (
    caidanid integer NOT NULL,
    caidanfuid integer NOT NULL,
    caidanbiaoti text NOT NULL,
    shunxu integer NOT NULL,
    kaishixian integer NOT NULL,
    mokuaiid integer NOT NULL,
    fudaicanshu text
);


ALTER TABLE public.zidian_caidan OWNER TO sa;

--
-- Name: TABLE zidian_caidan; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON TABLE zidian_caidan IS '菜单配置字典表';


--
-- Name: COLUMN zidian_caidan.caidanid; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_caidan.caidanid IS '菜单ID';


--
-- Name: COLUMN zidian_caidan.caidanfuid; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_caidan.caidanfuid IS '菜单父ID';


--
-- Name: COLUMN zidian_caidan.caidanbiaoti; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_caidan.caidanbiaoti IS '菜单标题';


--
-- Name: COLUMN zidian_caidan.shunxu; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_caidan.shunxu IS '顺序';


--
-- Name: COLUMN zidian_caidan.kaishixian; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_caidan.kaishixian IS '开始线';


--
-- Name: COLUMN zidian_caidan.mokuaiid; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_caidan.mokuaiid IS '模块ID';


--
-- Name: COLUMN zidian_caidan.fudaicanshu; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_caidan.fudaicanshu IS '附带参数';


--
-- Name: zidian_jiazai; Type: TABLE; Schema: public; Owner: sa; Tablespace: 
--

CREATE TABLE zidian_jiazai (
    jiazaiid integer NOT NULL,
    jiazaibiaoti text NOT NULL,
    mokuaiid integer NOT NULL,
    fudaicanshu text,
    jiazaishiji integer NOT NULL,
    shunxu integer NOT NULL
);


ALTER TABLE public.zidian_jiazai OWNER TO sa;

--
-- Name: TABLE zidian_jiazai; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON TABLE zidian_jiazai IS '模块加载时机配置信息表';


--
-- Name: COLUMN zidian_jiazai.jiazaiid; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_jiazai.jiazaiid IS '加载ID';


--
-- Name: COLUMN zidian_jiazai.jiazaibiaoti; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_jiazai.jiazaibiaoti IS '加载标题';


--
-- Name: COLUMN zidian_jiazai.mokuaiid; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_jiazai.mokuaiid IS '模块ID';


--
-- Name: COLUMN zidian_jiazai.fudaicanshu; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_jiazai.fudaicanshu IS '附带参数';


--
-- Name: COLUMN zidian_jiazai.jiazaishiji; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_jiazai.jiazaishiji IS '加载时机';


--
-- Name: COLUMN zidian_jiazai.shunxu; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_jiazai.shunxu IS '顺序';


--
-- Name: zidian_mokuai; Type: TABLE; Schema: public; Owner: sa; Tablespace: 
--

CREATE TABLE zidian_mokuai (
    mokuaiid integer NOT NULL,
    mokuaiming text NOT NULL,
    shoucan text,
    chushikejian integer NOT NULL,
    chushikeyong integer NOT NULL,
    mokuaileixing integer NOT NULL
);


ALTER TABLE public.zidian_mokuai OWNER TO sa;

--
-- Name: TABLE zidian_mokuai; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON TABLE zidian_mokuai IS '模块字典表';


--
-- Name: COLUMN zidian_mokuai.mokuaiid; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_mokuai.mokuaiid IS '模块ID';


--
-- Name: COLUMN zidian_mokuai.mokuaiming; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_mokuai.mokuaiming IS '模块名称';


--
-- Name: COLUMN zidian_mokuai.shoucan; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_mokuai.shoucan IS '首参';


--
-- Name: COLUMN zidian_mokuai.chushikejian; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_mokuai.chushikejian IS '初始可见';


--
-- Name: COLUMN zidian_mokuai.chushikeyong; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_mokuai.chushikeyong IS '初始可用';


--
-- Name: COLUMN zidian_mokuai.mokuaileixing; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_mokuai.mokuaileixing IS '模块类型';


--
-- Name: zidian_yonghu; Type: TABLE; Schema: public; Owner: sa; Tablespace: 
--

CREATE TABLE zidian_yonghu (
    yonghuid integer NOT NULL,
    yonghuming text NOT NULL,
    yonghumima text NOT NULL,
    zhenshixingming text NOT NULL,
    shifoutingyong integer NOT NULL
);


ALTER TABLE public.zidian_yonghu OWNER TO sa;

--
-- Name: TABLE zidian_yonghu; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON TABLE zidian_yonghu IS '用户字典表';


--
-- Name: COLUMN zidian_yonghu.yonghuid; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_yonghu.yonghuid IS '用户ID';


--
-- Name: COLUMN zidian_yonghu.yonghuming; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_yonghu.yonghuming IS '用户名';


--
-- Name: COLUMN zidian_yonghu.yonghumima; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_yonghu.yonghumima IS '密码';


--
-- Name: COLUMN zidian_yonghu.zhenshixingming; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_yonghu.zhenshixingming IS '真实姓名';


--
-- Name: COLUMN zidian_yonghu.shifoutingyong; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_yonghu.shifoutingyong IS '是否停用';


--
-- Name: zidian_yonghuzu; Type: TABLE; Schema: public; Owner: sa; Tablespace: 
--

CREATE TABLE zidian_yonghuzu (
    yonghuzuid integer NOT NULL,
    yonghuzuming text NOT NULL,
    shifoutingyong integer NOT NULL
);


ALTER TABLE public.zidian_yonghuzu OWNER TO sa;

--
-- Name: TABLE zidian_yonghuzu; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON TABLE zidian_yonghuzu IS '用户组字典表';


--
-- Name: COLUMN zidian_yonghuzu.yonghuzuid; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_yonghuzu.yonghuzuid IS '用户组ID';


--
-- Name: COLUMN zidian_yonghuzu.yonghuzuming; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_yonghuzu.yonghuzuming IS '用户组名称';


--
-- Name: COLUMN zidian_yonghuzu.shifoutingyong; Type: COMMENT; Schema: public; Owner: sa
--

COMMENT ON COLUMN zidian_yonghuzu.shifoutingyong IS '是否停用';


--
-- Name: xuhao; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY rizhi_denglu ALTER COLUMN xuhao SET DEFAULT nextval('rizhi_denglu_xuhao_seq'::regclass);


--
-- Data for Name: guanxi_fenzu; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY guanxi_fenzu (yonghuzuid, yonghuid) FROM stdin;
\.
COPY guanxi_fenzu (yonghuzuid, yonghuid) FROM '$$PATH$$/1998.dat';

--
-- Data for Name: rizhi_denglu; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY rizhi_denglu (xuhao, caozuoneirong, caozuoshijian, caozuorenyuanid) FROM stdin;
\.
COPY rizhi_denglu (xuhao, caozuoneirong, caozuoshijian, caozuorenyuanid) FROM '$$PATH$$/2006.dat';

--
-- Name: rizhi_denglu_xuhao_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('rizhi_denglu_xuhao_seq', 1, false);


--
-- Data for Name: xinxi_shouquan; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY xinxi_shouquan (xuliehao, cpuid) FROM stdin;
\.
COPY xinxi_shouquan (xuliehao, cpuid) FROM '$$PATH$$/2004.dat';

--
-- Data for Name: xinxi_yonghuquanxian; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY xinxi_yonghuquanxian (mokuaiid, yonghuid) FROM stdin;
\.
COPY xinxi_yonghuquanxian (mokuaiid, yonghuid) FROM '$$PATH$$/1999.dat';

--
-- Data for Name: xinxi_yonghuzuquanxian; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY xinxi_yonghuzuquanxian (yonghuzuid, mokuaiid) FROM stdin;
\.
COPY xinxi_yonghuzuquanxian (yonghuzuid, mokuaiid) FROM '$$PATH$$/2000.dat';

--
-- Data for Name: zidian_caidan; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY zidian_caidan (caidanid, caidanfuid, caidanbiaoti, shunxu, kaishixian, mokuaiid, fudaicanshu) FROM stdin;
\.
COPY zidian_caidan (caidanid, caidanfuid, caidanbiaoti, shunxu, kaishixian, mokuaiid, fudaicanshu) FROM '$$PATH$$/2002.dat';

--
-- Data for Name: zidian_jiazai; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY zidian_jiazai (jiazaiid, jiazaibiaoti, mokuaiid, fudaicanshu, jiazaishiji, shunxu) FROM stdin;
\.
COPY zidian_jiazai (jiazaiid, jiazaibiaoti, mokuaiid, fudaicanshu, jiazaishiji, shunxu) FROM '$$PATH$$/2003.dat';

--
-- Data for Name: zidian_mokuai; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY zidian_mokuai (mokuaiid, mokuaiming, shoucan, chushikejian, chushikeyong, mokuaileixing) FROM stdin;
\.
COPY zidian_mokuai (mokuaiid, mokuaiming, shoucan, chushikejian, chushikeyong, mokuaileixing) FROM '$$PATH$$/2001.dat';

--
-- Data for Name: zidian_yonghu; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY zidian_yonghu (yonghuid, yonghuming, yonghumima, zhenshixingming, shifoutingyong) FROM stdin;
\.
COPY zidian_yonghu (yonghuid, yonghuming, yonghumima, zhenshixingming, shifoutingyong) FROM '$$PATH$$/1996.dat';

--
-- Data for Name: zidian_yonghuzu; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY zidian_yonghuzu (yonghuzuid, yonghuzuming, shifoutingyong) FROM stdin;
\.
COPY zidian_yonghuzu (yonghuzuid, yonghuzuming, shifoutingyong) FROM '$$PATH$$/1997.dat';

--
-- Name: yueshu_zidian_caidan_biaoti; Type: CONSTRAINT; Schema: public; Owner: sa; Tablespace: 
--

ALTER TABLE ONLY zidian_caidan
    ADD CONSTRAINT yueshu_zidian_caidan_biaoti UNIQUE (caidanbiaoti);


--
-- Name: yueshu_zidian_caidan_shunxu; Type: CONSTRAINT; Schema: public; Owner: sa; Tablespace: 
--

ALTER TABLE ONLY zidian_caidan
    ADD CONSTRAINT yueshu_zidian_caidan_shunxu UNIQUE (caidanfuid, shunxu);


--
-- Name: yueshu_zidian_jiazai; Type: CONSTRAINT; Schema: public; Owner: sa; Tablespace: 
--

ALTER TABLE ONLY zidian_jiazai
    ADD CONSTRAINT yueshu_zidian_jiazai UNIQUE (jiazaibiaoti);


--
-- Name: yueshu_zidian_mokuai; Type: CONSTRAINT; Schema: public; Owner: sa; Tablespace: 
--

ALTER TABLE ONLY zidian_mokuai
    ADD CONSTRAINT yueshu_zidian_mokuai UNIQUE (mokuaiming);


--
-- Name: yueshu_zidian_yonghu; Type: CONSTRAINT; Schema: public; Owner: sa; Tablespace: 
--

ALTER TABLE ONLY zidian_yonghu
    ADD CONSTRAINT yueshu_zidian_yonghu UNIQUE (yonghuming);


--
-- Name: yueshu_zidian_yonghuzu; Type: CONSTRAINT; Schema: public; Owner: sa; Tablespace: 
--

ALTER TABLE ONLY zidian_yonghuzu
    ADD CONSTRAINT yueshu_zidian_yonghuzu UNIQUE (yonghuzuming);


--
-- Name: zhujian_guanxi_fenzu; Type: CONSTRAINT; Schema: public; Owner: sa; Tablespace: 
--

ALTER TABLE ONLY guanxi_fenzu
    ADD CONSTRAINT zhujian_guanxi_fenzu PRIMARY KEY (yonghuzuid, yonghuid);


--
-- Name: zhujian_rizhi_denglu; Type: CONSTRAINT; Schema: public; Owner: sa; Tablespace: 
--

ALTER TABLE ONLY rizhi_denglu
    ADD CONSTRAINT zhujian_rizhi_denglu PRIMARY KEY (xuhao);


--
-- Name: zhujian_xinxi_shouquan; Type: CONSTRAINT; Schema: public; Owner: sa; Tablespace: 
--

ALTER TABLE ONLY xinxi_shouquan
    ADD CONSTRAINT zhujian_xinxi_shouquan PRIMARY KEY (xuliehao);


--
-- Name: zhujian_xinxi_yonghuquanxian; Type: CONSTRAINT; Schema: public; Owner: sa; Tablespace: 
--

ALTER TABLE ONLY xinxi_yonghuquanxian
    ADD CONSTRAINT zhujian_xinxi_yonghuquanxian PRIMARY KEY (mokuaiid, yonghuid);


--
-- Name: zhujian_xinxi_yonghuzuquanxian; Type: CONSTRAINT; Schema: public; Owner: sa; Tablespace: 
--

ALTER TABLE ONLY xinxi_yonghuzuquanxian
    ADD CONSTRAINT zhujian_xinxi_yonghuzuquanxian PRIMARY KEY (yonghuzuid, mokuaiid);


--
-- Name: zhujian_zidian_caidan; Type: CONSTRAINT; Schema: public; Owner: sa; Tablespace: 
--

ALTER TABLE ONLY zidian_caidan
    ADD CONSTRAINT zhujian_zidian_caidan PRIMARY KEY (caidanid);


--
-- Name: zhujian_zidian_jiazai; Type: CONSTRAINT; Schema: public; Owner: sa; Tablespace: 
--

ALTER TABLE ONLY zidian_jiazai
    ADD CONSTRAINT zhujian_zidian_jiazai PRIMARY KEY (jiazaiid);


--
-- Name: zhujian_zidian_mokuai; Type: CONSTRAINT; Schema: public; Owner: sa; Tablespace: 
--

ALTER TABLE ONLY zidian_mokuai
    ADD CONSTRAINT zhujian_zidian_mokuai PRIMARY KEY (mokuaiid);


--
-- Name: zhujian_zidian_yonghu; Type: CONSTRAINT; Schema: public; Owner: sa; Tablespace: 
--

ALTER TABLE ONLY zidian_yonghu
    ADD CONSTRAINT zhujian_zidian_yonghu PRIMARY KEY (yonghuid);


--
-- Name: zhujian_zidian_yonghuzu; Type: CONSTRAINT; Schema: public; Owner: sa; Tablespace: 
--

ALTER TABLE ONLY zidian_yonghuzu
    ADD CONSTRAINT zhujian_zidian_yonghuzu PRIMARY KEY (yonghuzuid);


--
-- Name: suoyin_zidian_caidan; Type: INDEX; Schema: public; Owner: sa; Tablespace: 
--

CREATE INDEX suoyin_zidian_caidan ON zidian_caidan USING btree (caidanbiaoti);


--
-- Name: suoyin_zidian_mokuai; Type: INDEX; Schema: public; Owner: sa; Tablespace: 
--

CREATE INDEX suoyin_zidian_mokuai ON zidian_mokuai USING btree (mokuaiming);


--
-- Name: suoyin_zidian_yonghu; Type: INDEX; Schema: public; Owner: sa; Tablespace: 
--

CREATE INDEX suoyin_zidian_yonghu ON zidian_yonghu USING btree (yonghuming);


--
-- Name: suoyin_zidian_yonghuzu; Type: INDEX; Schema: public; Owner: sa; Tablespace: 
--

CREATE INDEX suoyin_zidian_yonghuzu ON zidian_yonghuzu USING btree (yonghuzuming);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

